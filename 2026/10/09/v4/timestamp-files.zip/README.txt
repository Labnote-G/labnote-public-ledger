FreeTSA: https://www.freetsa.org/index_en.php#online
Select Online Signature > Verify. Upload the matching <decimal serial>.tsq and .tsr files.
Use index.tsv to find the serial for a log fingerprint. Mapping is a convenience index; verify timestamps.json for the platform-signed mapping. Full original-content verification requires the private evidence package.
Files are extracted unchanged from timestamps.json; no new timestamps are requested.
